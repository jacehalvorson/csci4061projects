#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

int process_file(char *file_name)
{
    struct stat statbuf;
    if (stat(file_name, &statbuf) == -1)
    {
        perror("stat");
        return -1;
    }
    return statbuf.st_size;
}

int main(int argc, char **argv) {
    char *file_name;
    // If i remember right, the commented out version is the more inefficient version
    // but they both do the same thing

    // int pipe_fd[2];
    // for (int i = 1; i < argc; i++)
    // {
    //     file_name = argv[i];
    //     pipe(pipe_fd);

    //     pid_t child_pid = fork();
    //     if (child_pid == 0) // child
    //     {
    //         close(pipe_fd[0]); // indicates child only writes
    //         int result = process_file(file_name);
    //         write(pipe_fd[1], &result, sizeof(int));

    //         close(pipe_fd[1]); // close writing
    //         return 0;
    //     }
    //     else if (child_pid > 0) // parent
    //     {
    //         close(pipe_fd[1]); // indicates parent only reads
    //         int temp_result;
    //         read(pipe_fd[1], &temp_result, sizeof(int));
    //         printf("%dth result: %d\n", i, temp_result);
    //         close(pipe_fd[0]); // close reading

    //     }
    //     else if (child_pid < 0) // error
    //     {
    //         perror("fork");
    //         return 1;
    //     }
    // }

    int *pipe_fd = malloc(2 * (argc-1) * sizeof(int));
    for (int i = 0; i < argc-1; i++)
    {
        pipe(pipe_fd + 2*i);
        pid_t child_pid = fork();
        if (child_pid == 0) // child
        {
            for (int j = 0; j < i; j++)
            {
                close(pipe_fd[2*j]);
            }
            int result = process_file(argv[i+1]);
            write(pipe_fd[2*i + 1], &result, sizeof(int));
            close(pipe_fd[2*i + 1]);
            exit(0);
        }
        else if (child_pid > 0) // parent
        {
            close(pipe_fd[2*i + 1]);
        }
    }

    for (int i = 0; i < argc-1; i++)
    {
        int result;
        read(pipe_fd[2*i], &result, sizeof(int));
        printf("%s: %d B\n", argv[i+1], result);
    }
    free(pipe_fd);
}