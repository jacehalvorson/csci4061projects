#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>

// LAB 8 CODE - ONLY FOR REFERENCE

int main() {
    // Run equivalent of the command pipeline 'sort -r numbers.txt | head -n 10'

    // TODO Create pipe
    int a[2];
    pipe(a);

    pid_t child_pid = fork();
    if (child_pid == -1) {
        perror("fork");
        // TODO insert any necessary cleanup
        close(a[0]);
        close(a[1]);
        return 1;
    } else if (child_pid == 0) {
        // TODO Close write end of pipe
        close(a[1]);

        // TODO Run the 'head' command, setting up input from pipe first
        dup2(a[0], STDIN_FILENO);
        if (execlp("head", "head", "-n", "10", NULL) == -1)
        {
            perror("exec");
            //cleanup
            close(a[0]);
            return 1;
        }

        return 0; // Not reached on successful exec()
    } else {
        // TODO close read end of pipe
        close(a[0]);
    }

    // TODO Run the 'sort' command, setting up output to pipe first
    dup2(a[1], STDOUT_FILENO);
    if (execlp("sort", "sort", "-r", "numbers.txt", NULL) == -1)
    {
        perror("exec");
        //cleanup
        close(a[1]);
        return 1;
    }

    return 0; // Not reached on successful exec()
}
